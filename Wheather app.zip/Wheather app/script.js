const apiKey = "a9fad9ef4d7780f62dd00de4de425d1c";
const apiUrl = "https://api.openweathermap.org/data/2.5/weather?units=metric&q=";
document.getElementById("srcbtn").addEventListener('click', async function () {
    let city_Input = document.getElementById("city").value;
    const response = await fetch(apiUrl + city_Input + `&appid=${apiKey}`);
    var data = await response.json();
    console.log(data);
    document.querySelector(".city").innerHTML = data.name;
    document.querySelector(".temp").innerHTML = Math.round(data.main.temp) + "°C";
    document.querySelector(".humidity").innerHTML = data.main.humidity + "%";
    document.querySelector(".wind").innerHTML = data.wind.speed + "Km/h";
    if (data.weather[0].main == "Clouds") {
        weatherIcon.src = "clouds.png";
    }
    else if (data.weather[0].main == "Clouds") {
        weatherIcon.src = "clouds.png";
    }
    else if (data.weather[0].main == "Clear") {
        weatherIcon.src = "clear.png";
    }
    else if (data.weather[0].main == "Rain") {
        weatherIcon.src = "rain.png";
    }
    else if (data.weather[0].main == "Drizzle") {
        weatherIcon.src = "drizzle.png";
    }
    else if (data.weather[0].main == "Mist") {
        weatherIcon.src = "mist.png";
    }
    else if (data.weather[0].main == "Snow") {
        weatherIcon.src = "snow.png";
    }
    else if (data.weather[0].main == "Wind") {
        weatherIcon.src = "wind.png";
    }
    else if (data.weather[0].main == "Haze") {
        weatherIcon.src = "haze.png";
    }
    else if (data.weather[0].main == "Humidity") {
        weatherIcon.src = "humidity.png";
    }
})




